# TODO — RJ Juice

## Delivered: Bangladesh-only destination selection

- [x] A polished route-selection flow is limited exclusively to Bangladesh.
- [x] The player can choose any of Bangladesh's 64 districts from a map/list interface.
- [x] The selected district's division, terrain character, signature and landmark cue are shown before launch.

## Delivered: Playable RJ Juice sightseeing flight

- [x] The player is presented with a first-person cockpit-style view while looking out over Bangladesh from the sky.
- [x] Each flight begins with a runway takeoff sequence from the cockpit instead of spawning immediately at cruising altitude.
- [x] The aircraft is a branded private jet named **RJ Juice**, with a managed light business-jet asset plus procedural fallback.
- [x] Each selected location has a complete playable sightseeing loop with seven route waypoints.
- [x] Flyable controls include W/S throttle and reverse, arrow/Q/E climb and dive, A/D bank, mouse look, route waypoints, boost, V external chase view and pause/resume.

## Delivered: District scene foundation

- [x] All 64 districts are represented as expandable content records with coordinates, division, terrain metadata, rivers, landmarks and scene archetypes.
- [x] The scenes combine real district boundaries, OSM-derived major roads and named waterways with elevation-aware terrain, fields, village structures, trees, flight-obstacle towers, route gates and district-specific point-of-interest treatments.
- [x] Chattogram includes a recognizable port-zone treatment with cranes, ships and container massing.
- [x] Sylhet includes tea-garden terraces, wetland/river cues, distant hills and a Jaflong stone-river signature.
- [x] The visual system is professional and structured for future higher-fidelity real-place data packs.

## Delivered: Quality and delivery

- [x] The project remains on the initialized Three.js stack with the starter loop, input, save and tuning mechanisms preserved.
- [x] Game-specific loading treatment, favicon, sharing metadata and generated OG cover are installed.
- [x] TypeScript, production build, unit suite, real Preview screenshots and browser smoke flow pass.
- [x] The exact validated commit for the realistic geography upgrade is pushed to canonical `main`; publication remains intentionally off.

## Open fidelity expansion

- [ ] Add higher-detail satellite/land-cover imagery and custom landmark models for pixel-level realism. The current build is geographically grounded with open boundaries, roads, waterways and SRTM elevation, but it does not claim photogrammetry or pixel-for-pixel Google Earth replication.
