import * as THREE from 'three'
import { CONFIG } from './config'

export class FlightCamera {
  readonly camera = new THREE.PerspectiveCamera(72, 1, 0.1, 1200)
  yawOffset = 0
  pitchOffset = -0.08
  private bank = 0
  private bobTime = 0

  constructor() {
    this.camera.fov = 72
    this.camera.near = 0.08
    this.camera.far = 1200
    this.camera.updateProjectionMatrix()
  }

  reset(): void {
    this.yawOffset = 0
    this.pitchOffset = -0.08
    this.bank = 0
    this.bobTime = 0
  }

  look(delta: { x: number; y: number }): void {
    this.yawOffset = THREE.MathUtils.clamp(this.yawOffset - delta.x, -1.15, 1.15)
    this.pitchOffset = THREE.MathUtils.clamp(this.pitchOffset + delta.y, -0.78, 0.6)
  }

  update(position: THREE.Vector3, heading: number, pitch: number, bank: number, dt: number, reducedMotion: boolean): void {
    this.bobTime += dt
    this.bank = THREE.MathUtils.damp(this.bank, bank, 5, dt)
    const bob = reducedMotion ? 0 : Math.sin(this.bobTime * 2.3) * 0.028
    this.camera.position.set(position.x, position.y + 1.15 + bob, position.z)
    this.camera.rotation.order = 'YXZ'
    this.camera.rotation.y = heading + this.yawOffset
    this.camera.rotation.x = pitch + this.pitchOffset
    this.camera.rotation.z = -this.bank * 0.26
    const fov = CONFIG.camera.fov + 12
    if (this.camera.fov !== fov) {
      this.camera.fov = fov
      this.camera.updateProjectionMatrix()
    }
  }

  updateChase(position: THREE.Vector3, heading: number, bank: number, dt: number, reducedMotion: boolean): void {
    this.bobTime += dt
    const forward = new THREE.Vector3(Math.sin(heading), 0, -Math.cos(heading))
    const desired = position.clone().addScaledVector(forward, -25)
    desired.y += 9 + (reducedMotion ? 0 : Math.sin(this.bobTime * 1.8) * 0.4)
    this.camera.position.lerp(desired, 1 - Math.exp(-6 * dt))
    const target = position.clone().addScaledVector(forward, 18)
    target.y += 1.4
    this.camera.lookAt(target)
    this.camera.rotation.z = -bank * 0.12
    const fov = CONFIG.camera.fov + 4
    if (this.camera.fov !== fov) {
      this.camera.fov = fov
      this.camera.updateProjectionMatrix()
    }
  }
}
