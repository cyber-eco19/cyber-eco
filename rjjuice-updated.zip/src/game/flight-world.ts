import * as THREE from 'three'
import { Assets } from '../engine/assets'
import { DISTRICTS, type District, type SceneKind } from './districts'
import { rng } from './world'

const MODEL_URL = new URL('../../assets/models/aircraft-fleet-and-airfield-light-business-jet-4cb0858d.glb', import.meta.url).href
const GEO_SCALE = 86
const geographyPromise = Promise.all([
  fetch('/data/bangladesh-boundaries.json').then(response => response.json() as Promise<GeoCollection>),
  fetch('/data/bd-major-routes.json').then(response => response.json() as Promise<GeoCollection>),
  fetch('/data/bd-waterways.json').then(response => response.json() as Promise<GeoCollection>),
  fetch('/data/bangladesh-elevation.json').then(response => response.json() as Promise<ElevationCollection>),
])

type GeoFeature = { name: string; kind?: string; geometry: { type: string; coordinates: unknown } }
type GeoCollection = { features: GeoFeature[] }
type ElevationCollection = { size: number; tiles: Record<string, number[]> }

type Palette = { ground: string; field: string; water: string; accent: string; hill: string; roof: string }

const PALETTES: Record<SceneKind, Palette> = {
  urban: { ground: '#324d46', field: '#466e54', water: '#2b7c88', accent: '#e2b65b', hill: '#547368', roof: '#8b6b57' },
  port: { ground: '#36534c', field: '#4d765c', water: '#236f80', accent: '#e8ac4d', hill: '#4a6c62', roof: '#b5654f' },
  hill: { ground: '#335741', field: '#557d52', water: '#2d7784', accent: '#d6b35a', hill: '#3f7451', roof: '#9f7058' },
  tea: { ground: '#355d46', field: '#66934f', water: '#287d83', accent: '#edbe5a', hill: '#497c4d', roof: '#956d55' },
  wetland: { ground: '#425f4d', field: '#6d8e59', water: '#2c8291', accent: '#dfb55e', hill: '#57765f', roof: '#a27159' },
  river: { ground: '#3f624b', field: '#73945b', water: '#2d7b8c', accent: '#e8bb61', hill: '#57735c', roof: '#a5735a' },
  coastal: { ground: '#65735d', field: '#8aa56a', water: '#247a8d', accent: '#f0bb62', hill: '#75856c', roof: '#b2795b' },
  mangrove: { ground: '#315a4a', field: '#527852', water: '#236f7c', accent: '#e2b65c', hill: '#3b6d55', roof: '#8b6854' },
  orchard: { ground: '#496a4c', field: '#7e9d5b', water: '#2b7886', accent: '#e1b258', hill: '#607c52', roof: '#9b6b51' },
  farmland: { ground: '#66724c', field: '#9aab60', water: '#2c7d8a', accent: '#deb25d', hill: '#7c885a', roof: '#a37357' },
}

const mat = (color: string, roughness = 0.9, metalness = 0): THREE.MeshStandardMaterial => new THREE.MeshStandardMaterial({ color, roughness, metalness })

const terrainTexture = (palette: Palette): THREE.CanvasTexture => {
  const canvas = document.createElement('canvas')
  canvas.width = 256
  canvas.height = 256
  const context = canvas.getContext('2d')
  if (!context) return new THREE.CanvasTexture(canvas)
  context.fillStyle = palette.ground
  context.fillRect(0, 0, 256, 256)
  const colors = [palette.field, '#6b8155', '#7f8c61', '#4a6a50', palette.accent]
  for (let i = 0; i < 720; i += 1) {
    const x = (Math.sin(i * 12.7) * 0.5 + 0.5) * 256
    const y = (Math.cos(i * 8.3) * 0.5 + 0.5) * 256
    const size = 2 + (Math.sin(i * 3.1) * 0.5 + 0.5) * 12
    context.globalAlpha = 0.08 + (i % 7) * 0.012
    context.fillStyle = colors[i % colors.length]
    context.fillRect(x, y, size * 1.8, size)
  }
  context.globalAlpha = 1
  const texture = new THREE.CanvasTexture(canvas)
  texture.wrapS = THREE.RepeatWrapping
  texture.wrapT = THREE.RepeatWrapping
  texture.repeat.set(7, 7)
  texture.colorSpace = THREE.SRGBColorSpace
  return texture
}

export class FlightWorld {
  readonly scene = new THREE.Scene()
  readonly jetRoot = new THREE.Group()
  readonly routePoints: THREE.Vector3[] = []
  private readonly scenic = new THREE.Group()
  private readonly gates = new THREE.Group()
  private readonly clouds = new THREE.Group()
  private readonly labelLayer = new THREE.Group()
  private readonly assets = new Assets()
  private district: District = DISTRICTS[0]
  private geography: { boundaries: GeoCollection; routes: GeoCollection; waterways: GeoCollection; elevation: ElevationCollection } | null = null
  private time = 0
  private skyMaterial!: THREE.ShaderMaterial
  private hemi!: THREE.HemisphereLight
  private sunLight!: THREE.DirectionalLight
  private stars!: THREE.Points
  private baseSky = new THREE.Color('#8bb9c8')
  private hour = 12

  constructor() {
    this.scene.background = new THREE.Color('#8bb9c8')
    this.scene.fog = new THREE.Fog('#8bb9c8', 120, 520)
    this.scene.add(this.makeSky(), this.scenic, this.gates, this.clouds, this.labelLayer, this.jetRoot)
    this.hemi = new THREE.HemisphereLight('#d5eff4', '#38504b', 1.65)
    this.scene.add(this.hemi, this.makeStars())
    const sun = new THREE.DirectionalLight('#fff1cc', 3.2)
    this.sunLight = sun
    sun.position.set(-120, 220, 90)
    sun.castShadow = true
    sun.shadow.mapSize.set(2048, 2048)
    sun.shadow.camera.left = -180
    sun.shadow.camera.right = 180
    sun.shadow.camera.top = 180
    sun.shadow.camera.bottom = -180
    this.scene.add(sun)
    this.buildFallbackJet()
    void this.loadJet()
    this.selectDistrict(this.district)
    void this.loadGeography()
  }

  selectDistrict(district: District): void {
    this.district = district
    this.clearGroup(this.scenic)
    this.clearGroup(this.gates)
    this.clearGroup(this.labelLayer)
    this.routePoints.length = 0
    const palette = PALETTES[district.scene]
    const random = rng(Math.round((district.lat * 1000 + district.lon * 100) * 97))
    this.baseSky = new THREE.Color(this.backgroundFor(district.scene))
    this.scene.fog = new THREE.Fog(this.baseSky.clone(), 120, 520)
    this.setTimeOfDay(this.hour)
    this.addTerrain(palette, random, district)
    this.addRealGeography(district, palette)
    this.addWater(palette, random, district)
    this.addFields(palette, random)
    this.addScenery(palette, random)
    this.addInfrastructure(palette, random)
    this.addLandmark(district, palette, random)
    this.buildRoute(district, palette)
    this.addRunway(palette)
    this.addDistrictLabel(district, palette)
    this.jetRoot.visible = true
    this.jetRoot.position.copy(this.routePoints[0] ?? new THREE.Vector3(0, 76, 55))
  }

  setTimeOfDay(hour: number): void {
    this.hour = hour
    const angle = ((hour - 6) / 12) * Math.PI
    const elevation = Math.sin(angle)
    const day = THREE.MathUtils.smoothstep(elevation, -0.1, 0.4)
    const glow = Math.max(0, 1 - Math.abs(elevation - 0.05) * 3.2)
    const horizon = new THREE.Color('#070d1f').lerp(this.baseSky, day).lerp(new THREE.Color('#f0985a'), glow * 0.5)
    const top = new THREE.Color('#02050f').lerp(new THREE.Color('#274f71'), day).lerp(new THREE.Color('#44507f'), glow * 0.3)
    this.skyMaterial.uniforms.horizon.value.copy(horizon)
    this.skyMaterial.uniforms.top.value.copy(top)
    this.scene.background = horizon.clone()
    if (this.scene.fog instanceof THREE.Fog) this.scene.fog.color.copy(horizon)
    this.sunLight.position.set(-Math.cos(angle) * 220, Math.max(elevation, 0.04) * 220, 90)
    this.sunLight.intensity = 3.2 * day
    this.sunLight.color.set('#fff1cc').lerp(new THREE.Color('#ff8f4a'), glow * 0.8)
    this.hemi.intensity = 0.22 + 1.43 * day
    this.hemi.color.set('#2a3a6b').lerp(new THREE.Color('#d5eff4'), day)
    this.stars.visible = day < 0.6
    ;(this.stars.material as THREE.PointsMaterial).opacity = Math.min(1, (1 - day) * 1.3)
  }

  private makeStars(): THREE.Points {
    const count = 700
    const positions = new Float32Array(count * 3)
    for (let i = 0; i < count; i++) {
      const u = Math.random() * 2 - 1
      const a = Math.random() * Math.PI * 2
      const r = Math.sqrt(1 - u * u)
      positions.set([Math.cos(a) * r * 480, Math.abs(u) * 480, Math.sin(a) * r * 480], i * 3)
    }
    const geometry = new THREE.BufferGeometry()
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    this.stars = new THREE.Points(geometry, new THREE.PointsMaterial({ color: '#ffffff', size: 2, sizeAttenuation: false, transparent: true, fog: false, depthWrite: false }))
    this.stars.visible = false
    return this.stars
  }

  setInFlight(inFlight: boolean): void {
    this.jetRoot.visible = !inFlight
    for (const child of this.gates.children) child.visible = inFlight
  }

  setChaseView(chaseView: boolean): void {
    this.jetRoot.visible = chaseView
  }

  update(dt: number, activeGate: number): void {
    this.time += dt
    this.clouds.position.x = Math.sin(this.time * 0.012) * 6
    this.clouds.position.z = Math.cos(this.time * 0.01) * 4
    this.gates.children.forEach((gate, index) => {
      const ring = gate as THREE.Mesh
      ring.rotation.z += dt * 0.08
      const material = ring.material as THREE.MeshStandardMaterial
      material.emissiveIntensity = index === activeGate ? 3.2 + Math.sin(this.time * 4) * 0.55 : 0.65
      material.opacity = index === activeGate ? 0.98 : 0.33
    })
  }

  syncJet(position: THREE.Vector3, heading: number): void {
    this.jetRoot.position.copy(position)
    this.jetRoot.rotation.y = heading
  }

  dispose(): void {
    this.clearGroup(this.scenic)
    this.clearGroup(this.gates)
    this.clearGroup(this.clouds)
    this.clearGroup(this.labelLayer)
  }

  private async loadJet(): Promise<void> {
    try {
      const gltf = await this.assets.gltf(MODEL_URL)
      const loaded = gltf.scene.clone(true)
      const box = new THREE.Box3().setFromObject(loaded)
      const size = box.getSize(new THREE.Vector3())
      const length = Math.max(size.x, size.z, 0.01)
      loaded.scale.setScalar(11 / length)
      loaded.rotation.y = Math.PI
      loaded.position.y = 0.45
      loaded.traverse(node => {
        if (node instanceof THREE.Mesh) {
          node.castShadow = true
          node.receiveShadow = true
        }
      })
      this.jetRoot.clear()
      this.jetRoot.add(loaded, this.brandWing(), this.brandTail())
    } catch {
      // The compact procedural jet remains in place if the managed GLB cannot be restored.
    }
  }

  private async loadGeography(): Promise<void> {
    const [boundaries, routes, waters, elevation] = await geographyPromise
    this.geography = {
      boundaries,
      routes,
      waterways: waters,
      elevation,
    }
    this.selectDistrict(this.district)
  }

  private buildFallbackJet(): void {
    const body = new THREE.Mesh(new THREE.CapsuleGeometry(0.55, 4.8, 8, 18), mat('#f4f1e7', 0.34, 0.25))
    body.rotation.z = Math.PI / 2
    body.position.y = 1.15
    const nose = new THREE.Mesh(new THREE.ConeGeometry(0.55, 1.65, 18), mat('#ecf5f4', 0.28, 0.3))
    nose.rotation.z = -Math.PI / 2
    nose.position.x = 2.85
    nose.position.y = 1.15
    const wing = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.1, 0.6), mat('#79e6e8', 0.38, 0.45))
    wing.position.y = 0.82
    const tail = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.12, 0.28), mat('#d9a942', 0.35, 0.4))
    tail.position.set(-2.15, 1.72, 0)
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.75, 0.12), mat('#d9a942', 0.35, 0.35))
    fin.position.set(-2.1, 1.62, 0)
    this.jetRoot.add(body, nose, wing, tail, fin, this.brandWing(), this.brandTail())
  }

  private brandWing(): THREE.Mesh {
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.035, 0.06), new THREE.MeshStandardMaterial({ color: '#79e6e8', emissive: '#3ba9ae', emissiveIntensity: 1.3, metalness: 0.25, roughness: 0.3 }))
    stripe.position.set(0.2, 1.17, 0.61)
    return stripe
  }

  private brandTail(): THREE.Mesh {
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.04, 0.08), new THREE.MeshStandardMaterial({ color: '#e7b74d', emissive: '#9e6c1d', emissiveIntensity: 0.8, metalness: 0.35, roughness: 0.3 }))
    stripe.position.set(-1.85, 1.42, 0.54)
    return stripe
  }

  private addTerrain(palette: Palette, random: () => number, district: District): void {
    const elevation = this.geography?.elevation
    const tileKey = `N${Math.floor(district.lat)}E${String(Math.floor(district.lon)).padStart(3, '0')}`
    const grid = elevation?.tiles[tileKey]
    const geometry = new THREE.PlaneGeometry(620, 620, grid && elevation ? elevation.size - 1 : 32, grid && elevation ? elevation.size - 1 : 32)
    if (grid) {
      const position = geometry.attributes.position
      for (let i = 0; i < position.count; i += 1) {
        const x = i % (elevation?.size ?? 64)
        const y = Math.floor(i / (elevation?.size ?? 64))
        position.setZ(i, Math.max(-2, grid[y * (elevation?.size ?? 64) + x] * 0.12))
      }
      geometry.computeVertexNormals()
    }
    const ground = new THREE.Mesh(geometry, new THREE.MeshStandardMaterial({ color: '#ffffff', map: terrainTexture(palette), roughness: 1, metalness: 0 }))
    ground.rotation.x = -Math.PI / 2
    ground.receiveShadow = true
    this.scenic.add(ground)
    for (let i = 0; i < 70; i += 1) {
      const x = (random() - 0.5) * 540
      const z = (random() - 0.5) * 540
      const tile = new THREE.Mesh(new THREE.PlaneGeometry(20 + random() * 18, 12 + random() * 16), mat(random() > 0.4 ? palette.field : palette.ground, 1))
      tile.rotation.x = -Math.PI / 2
      tile.rotation.z = random() * Math.PI
      tile.position.set(x, 0.012, z)
      this.scenic.add(tile)
    }
    for (let i = 0; i < (grid ? 0 : 16); i += 1) {
      const hill = new THREE.Mesh(new THREE.ConeGeometry(18 + random() * 24, 16 + random() * 34, 9), mat(palette.hill, 1))
      hill.position.set((random() - 0.5) * 330, 10 + random() * 10, (random() - 0.5) * 330)
      hill.scale.y = 0.65
      hill.receiveShadow = true
      hill.castShadow = true
      this.scenic.add(hill)
    }
  }

  private addWater(palette: Palette, random: () => number, district: District): void {
    const realWater = this.addRealWaterways(district)
    if (realWater > 0) return
    const path = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-260, 0.07, -20), new THREE.Vector3(-160, 0.08, 12 + random() * 30), new THREE.Vector3(-70, 0.09, -16), new THREE.Vector3(20, 0.1, 22), new THREE.Vector3(105, 0.08, -8), new THREE.Vector3(210, 0.08, 26), new THREE.Vector3(300, 0.08, -10),
    ])
    const river = new THREE.Mesh(new THREE.TubeGeometry(path, 48, 6.4, 8, false), new THREE.MeshStandardMaterial({ color: palette.water, roughness: 0.22, metalness: 0.16, transparent: true, opacity: 0.92 }))
    river.castShadow = false
    this.scenic.add(river)
    const shore = new THREE.Mesh(new THREE.TubeGeometry(path, 48, 6.9, 6, false), new THREE.MeshBasicMaterial({ color: '#83d7cf', transparent: true, opacity: 0.08, side: THREE.DoubleSide }))
    this.scenic.add(shore)
  }

  private addRealWaterways(district: District): number {
    const collection = this.geography?.waterways
    if (!collection) return 0
    let drawn = 0
    for (const water of collection.features) {
      if (drawn >= 14) break
      const lines = water.geometry.type === 'LineString'
        ? [water.geometry.coordinates as number[][]]
        : water.geometry.type === 'MultiLineString'
          ? water.geometry.coordinates as number[][][]
          : []
      for (const coordinates of lines) {
        if (drawn >= 14 || coordinates.length < 2) break
        if (!coordinates.some(point => Math.abs(point[0] - district.lon) < 1.35 && Math.abs(point[1] - district.lat) < 1.35)) continue
        const points = coordinates.map(([lon, lat]) => new THREE.Vector3((lon - district.lon) * GEO_SCALE, 0.18, -(lat - district.lat) * GEO_SCALE))
        const curve = new THREE.CatmullRomCurve3(points)
        const radius = water.kind === 'river' ? 5.5 : water.kind === 'canal' ? 1.8 : 0.6
        const mesh = new THREE.Mesh(new THREE.TubeGeometry(curve, Math.min(48, points.length * 3), radius, 7, false), new THREE.MeshStandardMaterial({ color: water.kind === 'river' ? '#2d8293' : '#3a8b8c', roughness: 0.2, metalness: 0.12, transparent: true, opacity: water.kind === 'river' ? 0.88 : 0.72 }))
        this.scenic.add(mesh)
        drawn += 1
      }
    }
    return drawn
  }

  private addRealGeography(district: District, palette: Palette): void {
    const geography = this.geography
    if (!geography) return
    const boundaries = geography.boundaries
    const boundary = boundaries.features.find(feature => feature.name.toLowerCase() === district.name.toLowerCase())
    if (boundary) {
      this.addGeoPolygon(boundary.geometry, district, palette)
    }
    const routes = geography.routes
    let drawn = 0
    for (const route of routes.features) {
      if (drawn >= 160) break
      const coordinates = route.geometry.coordinates
      if (route.geometry.type !== 'LineString' || !Array.isArray(coordinates)) continue
      const points = coordinates as number[][]
      if (!points.some(point => Math.abs(point[0] - district.lon) < 1.7 && Math.abs(point[1] - district.lat) < 1.7)) continue
      const linePoints = points.map(([lon, lat]) => new THREE.Vector3((lon - district.lon) * GEO_SCALE, 0.24, -(lat - district.lat) * GEO_SCALE))
      const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(linePoints), new THREE.LineBasicMaterial({ color: route.name ? '#d0c68e' : '#929b8d', transparent: true, opacity: 0.66 }))
      this.scenic.add(line)
      drawn += 1
    }
  }

  private addGeoPolygon(geometry: { type: string; coordinates: unknown }, district: District, palette: Palette): void {
    const polygons: number[][][][] = geometry.type === 'Polygon'
      ? [geometry.coordinates as number[][][]]
      : geometry.type === 'MultiPolygon'
        ? geometry.coordinates as number[][][][]
        : []
    for (const polygon of polygons) {
      const outer = polygon[0]
      if (!outer || outer.length < 3) continue
      const points = outer.map(([lon, lat]) => new THREE.Vector3((lon - district.lon) * GEO_SCALE, 0.18, -(lat - district.lat) * GEO_SCALE))
      const boundary = new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(points), new THREE.LineBasicMaterial({ color: palette.accent, transparent: true, opacity: 0.9 }))
      this.scenic.add(boundary)
      const shape = new THREE.Shape()
      outer.forEach(([lon, lat], index) => {
        const x = (lon - district.lon) * GEO_SCALE
        const y = -(lat - district.lat) * GEO_SCALE
        if (index === 0) shape.moveTo(x, y)
        else shape.lineTo(x, y)
      })
      const fill = new THREE.Mesh(new THREE.ShapeGeometry(shape), new THREE.MeshBasicMaterial({ color: palette.accent, transparent: true, opacity: 0.045, side: THREE.DoubleSide, depthWrite: false }))
      fill.rotation.x = -Math.PI / 2
      fill.position.y = 0.14
      this.scenic.add(fill)
    }
  }

  private addFields(palette: Palette, random: () => number): void {
    for (let i = 0; i < 46; i += 1) {
      const field = new THREE.Mesh(new THREE.BoxGeometry(8 + random() * 9, 0.08, 3.2 + random() * 4), mat(i % 3 === 0 ? palette.accent : palette.field, 1))
      field.position.set((random() - 0.5) * 320, 0.08, (random() - 0.5) * 300)
      field.rotation.y = random() * Math.PI
      this.scenic.add(field)
    }
  }

  private addScenery(palette: Palette, random: () => number): void {
    for (let i = 0; i < 58; i += 1) {
      const group = new THREE.Group()
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.28, 2.4 + random() * 2.2, 6), mat('#755b3c', 1))
      trunk.position.y = 1.3
      const crown = new THREE.Mesh(new THREE.IcosahedronGeometry(1.5 + random() * 1.5, 1), mat(i % 5 === 0 ? palette.accent : '#477f55', 1))
      crown.position.y = 3.3 + random() * 1.5
      group.add(trunk, crown)
      group.position.set((random() - 0.5) * 330, 0, (random() - 0.5) * 320)
      group.scale.setScalar(0.65 + random() * 0.75)
      group.castShadow = true
      this.scenic.add(group)
    }
    for (let i = 0; i < 20; i += 1) {
      const hut = new THREE.Mesh(new THREE.BoxGeometry(3.4, 1.5, 2.4), mat(palette.roof, 0.85))
      hut.position.set((random() - 0.5) * 260, 0.8, (random() - 0.5) * 260)
      hut.castShadow = true
      this.scenic.add(hut)
    }
    this.addClouds(random)
  }

  private addInfrastructure(palette: Palette, random: () => number): void {
    for (let i = 0; i < 8; i += 1) {
      const road = new THREE.Group()
      const asphalt = new THREE.Mesh(new THREE.BoxGeometry(72 + random() * 42, 0.12, 2.6 + random() * 1.4), mat('#263c40', 0.94))
      asphalt.position.y = 0.11
      road.add(asphalt)
      for (let dash = -4; dash <= 4; dash += 1) {
        const marking = new THREE.Mesh(new THREE.BoxGeometry(7, 0.03, 0.12), mat(palette.accent, 0.8))
        marking.position.set(dash * 11, 0.19, 0)
        road.add(marking)
      }
      road.position.set((random() - 0.5) * 320, 0, (random() - 0.5) * 270)
      road.rotation.y = random() * Math.PI
      this.scenic.add(road)
    }
    for (let i = 0; i < 7; i += 1) {
      const tower = new THREE.Group()
      const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.3, 14 + random() * 12, 6), mat('#657a77', 0.62, 0.28))
      mast.position.y = 7
      tower.add(mast)
      for (const y of [4.5, 8.5, 12.5]) {
        const arm = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.12, 0.12), mat('#c4d1c9', 0.62, 0.25))
        arm.position.y = y
        tower.add(arm)
      }
      const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.35, 8, 8), new THREE.MeshStandardMaterial({ color: '#ff766d', emissive: '#ff3e47', emissiveIntensity: 2.2 }))
      beacon.position.y = 14 + random() * 8
      tower.add(beacon)
      tower.position.set((random() - 0.5) * 280, 0, (random() - 0.5) * 260)
      tower.traverse(object => { if (object instanceof THREE.Mesh) object.castShadow = true })
      this.scenic.add(tower)
    }
  }

  private addLandmark(district: District, palette: Palette, random: () => number): void {
    const anchor = new THREE.Group()
    anchor.position.set(0, 0, -4)
    if (district.scene === 'port') {
      for (let i = -1; i <= 1; i += 1) this.addCrane(anchor, i * 15, palette.accent)
      for (let i = -2; i <= 2; i += 1) {
        const ship = new THREE.Mesh(new THREE.BoxGeometry(11, 1.3, 3.8), mat('#d4d6d1', 0.45, 0.35))
        ship.position.set(i * 12, 0.9, -22 - Math.abs(i) * 2)
        anchor.add(ship)
      }
      const stack = new THREE.Mesh(new THREE.BoxGeometry(7, 4, 3), mat('#e48a50', 0.7))
      stack.position.set(0, 2, -22)
      anchor.add(stack)
    } else if (district.scene === 'tea') {
      for (let row = 0; row < 8; row += 1) {
        const terrace = new THREE.Mesh(new THREE.BoxGeometry(38 - row * 2.4, 0.55, 2.4), mat('#6d9b4f', 1))
        terrace.position.set(0, row * 0.35 + 0.3, -16 - row * 3.6)
        anchor.add(terrace)
      }
      for (let i = 0; i < 9; i += 1) {
        const teaTree = new THREE.Mesh(new THREE.SphereGeometry(1.25, 12, 8), mat('#3e774c', 1))
        teaTree.position.set(-24 + i * 6, 1.2, 8 + random() * 6)
        anchor.add(teaTree)
      }
    } else if (district.scene === 'urban') {
      for (let i = 0; i < 14; i += 1) {
        const building = new THREE.Mesh(new THREE.BoxGeometry(3 + random() * 5, 4 + random() * 16, 3 + random() * 5), mat(i % 3 === 0 ? '#8a9994' : '#b6a681', 0.65, 0.1))
        building.position.set((random() - 0.5) * 80, building.geometry.parameters.height / 2, -45 + random() * 55)
        anchor.add(building)
      }
      const tower = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 2.6, 18, 8), mat(palette.accent, 0.4, 0.25))
      tower.position.set(0, 9, -45)
      anchor.add(tower)
    } else if (district.scene === 'hill') {
      for (let i = 0; i < 8; i += 1) {
        const ridge = new THREE.Mesh(new THREE.ConeGeometry(9 + random() * 8, 30 + random() * 22, 7), mat(palette.hill, 1))
        ridge.position.set((random() - 0.5) * 120, 14, -55 - random() * 70)
        ridge.scale.z = 0.75
        anchor.add(ridge)
      }
    } else if (district.scene === 'mangrove') {
      for (let i = 0; i < 20; i += 1) {
        const tree = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.42, 5 + random() * 4, 7), mat('#4d6c45', 1))
        tree.position.set((random() - 0.5) * 80, 2.5, -40 - random() * 55)
        anchor.add(tree)
      }
    } else {
      const bridge = new THREE.Group()
      const deck = new THREE.Mesh(new THREE.BoxGeometry(38, 0.9, 3), mat('#697b78', 0.55, 0.35))
      deck.position.y = 4
      bridge.add(deck)
      for (const x of [-14, 14]) {
        const pillar = new THREE.Mesh(new THREE.BoxGeometry(1.8, 10, 1.8), mat(palette.accent, 0.42, 0.25))
        pillar.position.set(x, 5, 0)
        bridge.add(pillar)
      }
      bridge.position.set(0, 0, -40)
      anchor.add(bridge)
    }
    anchor.traverse(obj => { if (obj instanceof THREE.Mesh) { obj.castShadow = true; obj.receiveShadow = true } })
    this.scenic.add(anchor)
  }

  private addRunway(palette: Palette): void {
    const start = this.routePoints[0]
    const next = this.routePoints[1]
    if (!start || !next) return
    const runway = new THREE.Group()
    const asphalt = new THREE.Mesh(new THREE.BoxGeometry(18, 0.16, 220), mat('#273b3d', 0.96))
    runway.add(asphalt)
    for (let z = -86; z <= 86; z += 22) {
      const centerline = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.035, 9), mat('#e7dca5', 0.82))
      centerline.position.set(0, 0.1, z)
      runway.add(centerline)
    }
    for (const z of [-98, 98]) {
      for (const x of [-9, 9]) {
        const light = new THREE.Mesh(new THREE.SphereGeometry(0.3, 8, 8), new THREE.MeshStandardMaterial({ color: palette.accent, emissive: palette.accent, emissiveIntensity: 1.8 }))
        light.position.set(x, 0.4, z)
        runway.add(light)
      }
    }
    runway.position.set(start.x, 0.06, start.z)
    runway.rotation.y = Math.atan2(next.x - start.x, -(next.z - start.z))
    this.scenic.add(runway)
  }

  private addCrane(parent: THREE.Group, x: number, color: string): void {
    const crane = new THREE.Group()
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.9, 17, 0.9), mat('#a9aaa1', 0.55, 0.25))
    leg.position.y = 8.5
    const arm = new THREE.Mesh(new THREE.BoxGeometry(12, 0.6, 0.6), mat(color, 0.4, 0.3))
    arm.position.set(4, 16.5, 0)
    const cable = new THREE.Mesh(new THREE.BoxGeometry(0.08, 8, 0.08), mat('#e1e2d8', 0.5, 0.2))
    cable.position.set(9, 12.5, 0)
    crane.add(leg, arm, cable)
    crane.position.set(x, 0, -28)
    parent.add(crane)
  }

  private buildRoute(district: District, palette: Palette): void {
    const random = rng(district.id.length * 1049 + Math.round(district.lat * 10))
    const radius = district.scene === 'hill' || district.scene === 'tea' ? 92 : 108
    for (let i = 0; i < 7; i += 1) {
      const angle = i / 7 * Math.PI * 2 - Math.PI / 2
      const point = new THREE.Vector3(Math.cos(angle) * (radius + random() * 18), 68 + random() * 28, Math.sin(angle) * (radius + random() * 18))
      this.routePoints.push(point)
      const ring = new THREE.Mesh(new THREE.TorusGeometry(6.3, 0.18, 10, 48), new THREE.MeshStandardMaterial({ color: '#79e6e8', emissive: '#2e999d', emissiveIntensity: 0.8, transparent: true, opacity: 0.36, metalness: 0.15, roughness: 0.28 }))
      ring.position.copy(point)
      ring.rotation.x = Math.PI / 2
      ring.userData.index = i
      this.gates.add(ring)
    }
    const route = new THREE.CatmullRomCurve3([...this.routePoints, this.routePoints[0]])
    const line = new THREE.Mesh(new THREE.TubeGeometry(route, 100, 0.06, 5, false), new THREE.MeshBasicMaterial({ color: palette.accent, transparent: true, opacity: 0.38 }))
    this.gates.add(line)
  }

  private addClouds(random: () => number): void {
    for (let i = 0; i < 14; i += 1) {
      const cloud = new THREE.Group()
      for (let j = 0; j < 4; j += 1) {
        const puff = new THREE.Mesh(new THREE.SphereGeometry(5 + random() * 4, 12, 8), new THREE.MeshStandardMaterial({ color: '#eef6f2', transparent: true, opacity: 0.72, roughness: 1 }))
        puff.position.set(j * 4.5, random() * 3, random() * 3)
        cloud.add(puff)
      }
      cloud.position.set((random() - 0.5) * 460, 88 + random() * 58, (random() - 0.5) * 420)
      cloud.scale.setScalar(0.65 + random() * 0.7)
      this.clouds.add(cloud)
    }
  }

  private addDistrictLabel(district: District, palette: Palette): void {
    const badge = this.makeTextSprite(`${district.name.toUpperCase()}  /  ${district.divisionShort}`, '#dff9f7', '#152b32')
    badge.position.set(0, 22, -34)
    badge.scale.set(22, 5.5, 1)
    this.labelLayer.add(badge)
    const landmark = this.makeTextSprite(district.landmark.toUpperCase(), palette.accent, '#152b32')
    landmark.position.set(0, 15, -34)
    landmark.scale.set(18, 3.4, 1)
    this.labelLayer.add(landmark)
  }

  private makeTextSprite(text: string, foreground: string, background: string): THREE.Sprite {
    const canvas = document.createElement('canvas')
    canvas.width = 1024
    canvas.height = 192
    const ctx = canvas.getContext('2d')!
    ctx.fillStyle = `${background}dd`
    ctx.beginPath()
    ctx.roundRect(10, 10, canvas.width - 20, canvas.height - 20, 26)
    ctx.fill()
    ctx.strokeStyle = `${foreground}66`
    ctx.lineWidth = 3
    ctx.stroke()
    ctx.fillStyle = foreground
    ctx.font = '700 48px ManusCC0, sans-serif'
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillText(text, canvas.width / 2, canvas.height / 2 + 2)
    const texture = new THREE.CanvasTexture(canvas)
    texture.colorSpace = THREE.SRGBColorSpace
    return new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false }))
  }

  private makeSky(): THREE.Mesh {
    const material = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: { top: { value: new THREE.Color('#274f71') }, horizon: { value: new THREE.Color('#b9d7cf') } },
      vertexShader: 'varying vec3 vDir; void main(){vDir=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}',
      fragmentShader: 'uniform vec3 top; uniform vec3 horizon; varying vec3 vDir; void main(){float h=clamp(vDir.y,0.0,1.0); vec3 c=mix(horizon,top,pow(h,0.45)); gl_FragColor=vec4(c,1.0);}',
    })
    this.skyMaterial = material
    const sky = new THREE.Mesh(new THREE.SphereGeometry(500, 32, 18), material)
    sky.renderOrder = -1
    return sky
  }

  private backgroundFor(scene: SceneKind): string {
    return scene === 'coastal' || scene === 'port' ? '#87bdc9' : scene === 'hill' || scene === 'tea' ? '#83aeb1' : '#9cc9c7'
  }

  private clearGroup(group: THREE.Group): void {
    while (group.children.length) {
      const child = group.children.pop()!
      child.traverse(obj => {
        if (obj instanceof THREE.Mesh) {
          obj.geometry.dispose()
          const material = obj.material
          for (const m of Array.isArray(material) ? material : material ? [material] : []) {
            m.dispose()
          }
        }
      })
    }
  }
}
