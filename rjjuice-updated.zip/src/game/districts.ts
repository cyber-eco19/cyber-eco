export type SceneKind = 'urban' | 'port' | 'hill' | 'tea' | 'wetland' | 'river' | 'coastal' | 'mangrove' | 'orchard' | 'farmland'

export type District = {
  id: string
  name: string
  division: string
  divisionShort: string
  lat: number
  lon: number
  tag: string
  terrain: string
  landmark: string
  river: string
  scene: SceneKind
  accent: string
}

const d = (id: string, name: string, division: string, divisionShort: string, lat: number, lon: number, tag: string, terrain: string, landmark: string, river: string, scene: SceneKind, accent: string): District => ({ id, name, division, divisionShort, lat, lon, tag, terrain, landmark, river, scene, accent })

/** The complete Bangladesh district spine. Coordinates are used for navigation presentation and scene seeds. */
export const DISTRICTS: District[] = [
  d('dhaka', 'Dhaka', 'Dhaka Division', 'DHA', 23.81, 90.41, 'CAPITAL PULSE', 'dense city fabric and river light', 'National Parliament skyline', 'Buriganga', 'urban', '#d7a44a'),
  d('faridpur', 'Faridpur', 'Dhaka Division', 'DHA', 23.61, 89.84, 'RIVER PLAINS', 'wide floodplain, homesteads and fields', 'Padma river bends', 'Padma', 'river', '#6ec3a2'),
  d('gazipur', 'Gazipur', 'Dhaka Division', 'DHA', 24.00, 90.42, 'GREEN EDGE', 'sal forest, industry and fast-growing town', 'Bhawal forest canopy', 'Turag', 'urban', '#74c69d'),
  d('gopalganj', 'Gopalganj', 'Dhaka Division', 'DHA', 23.01, 89.83, 'LOWLAND MIRROR', 'quiet lowland water and village clusters', 'Madhumati waterways', 'Madhumati', 'wetland', '#65c7bb'),
  d('kishoreganj', 'Kishoreganj', 'Dhaka Division', 'DHA', 24.44, 90.78, 'HAOR COUNTRY', 'seasonal haor water, rice and open sky', 'Nikli haor horizon', 'Meghna', 'wetland', '#79b9c7'),
  d('madaripur', 'Madaripur', 'Dhaka Division', 'DHA', 23.17, 90.19, 'CHANNEL COUNTRY', 'canals, palms and soft river banks', 'Arial Khan channel', 'Arial Khan', 'river', '#72c5aa'),
  d('manikganj', 'Manikganj', 'Dhaka Division', 'DHA', 23.86, 90.00, 'PADMA APPROACH', 'river chars and patchwork agriculture', 'Padma ferry corridor', 'Padma', 'river', '#72c3a8'),
  d('munshiganj', 'Munshiganj', 'Dhaka Division', 'DHA', 23.55, 90.53, 'RIVER GATE', 'busy waterways, orchards and flat delta', 'Padma–Meghna confluence', 'Meghna', 'river', '#6fc7b6'),
  d('narayanganj', 'Narayanganj', 'Dhaka Division', 'DHA', 23.62, 90.50, 'INDUSTRIAL RIVER', 'dense riverfront and warehouse belts', 'Shitalakshya riverfront', 'Shitalakshya', 'urban', '#d3a34e'),
  d('narsingdi', 'Narsingdi', 'Dhaka Division', 'DHA', 23.92, 90.72, 'TEXTILE BELT', 'factory roofs, fields and Meghna light', 'Meghna river edge', 'Meghna', 'urban', '#d6a757'),
  d('rajbari', 'Rajbari', 'Dhaka Division', 'DHA', 23.76, 89.65, 'CHAR LANDS', 'sweeping sandbars and green banks', 'Goalanda river crossing', 'Padma', 'river', '#70c2a5'),
  d('shariatpur', 'Shariatpur', 'Dhaka Division', 'DHA', 23.24, 90.35, 'DELTA THREADS', 'braided channels, boats and homesteads', 'Kirtinasha bends', 'Kirtinasha', 'river', '#65c3b4'),
  d('tangail', 'Tangail', 'Dhaka Division', 'DHA', 24.25, 89.92, 'NORTHWEST GATE', 'red earth, fields and Jamuna banks', 'Jamuna river panorama', 'Jamuna', 'river', '#73b999'),

  d('bandarban', 'Bandarban', 'Chattogram Division', 'CTG', 22.20, 92.22, 'HILL TRAILS', 'steep green ridges and winding valleys', 'Nilgiri hill silhouette', 'Sangu', 'hill', '#82b675'),
  d('brahmanbaria', 'Brahmanbaria', 'Chattogram Division', 'CTG', 23.96, 91.11, 'EASTERN PLAIN', 'river plains, crop grids and town ribbon', 'Titas river meander', 'Titas', 'river', '#73c1a4'),
  d('chandpur', 'Chandpur', 'Chattogram Division', 'CTG', 23.23, 90.67, 'THREE RIVERS', 'wide water meeting points and chars', 'Meghna river confluence', 'Meghna', 'river', '#67c7bd'),
  d('chattogram', 'Chattogram', 'Chattogram Division', 'CTG', 22.36, 91.78, 'PORT CITY', 'coast, hills, cranes and dense city edges', 'Chattogram Port cranes', 'Karnaphuli', 'port', '#e1a34e'),
  d('cumilla', 'Cumilla', 'Chattogram Division', 'CTG', 23.46, 91.18, 'RED SOIL RIDGE', 'rolling plain, ponds and old town', 'Mainamati ridge', 'Gomti', 'orchard', '#b9a05e'),
  d('coxsbazar', "Cox's Bazar", 'Chattogram Division', 'CTG', 21.43, 92.00, 'BAY OF BENGAL', 'long beach, surf line and coastal palms', 'Cox’s Bazar beach arc', 'Bakkhali', 'coastal', '#d7a86a'),
  d('feni', 'Feni', 'Chattogram Division', 'CTG', 23.02, 91.40, 'COASTAL PLAIN', 'paddy fields, canals and highway trace', 'Feni river crossing', 'Feni', 'farmland', '#76bd8d'),
  d('khagrachhari', 'Khagrachhari', 'Chattogram Division', 'CTG', 23.12, 91.98, 'CLOUD HILLS', 'folded hills, bamboo and valley villages', 'Alutila hill cut', 'Chengi', 'hill', '#7bad6e'),
  d('lakshmipur', 'Lakshmipur', 'Chattogram Division', 'CTG', 22.94, 90.84, 'COASTAL DELTA', 'flat delta, ponds and coconut groves', 'Meghna estuary edge', 'Meghna', 'coastal', '#6fc4aa'),
  d('noakhali', 'Noakhali', 'Chattogram Division', 'CTG', 22.87, 91.10, 'CHAR COAST', 'new land, tidal channels and salt wind', 'Hatiya channel view', 'Meghna', 'coastal', '#68c1b3'),
  d('rangamati', 'Rangamati', 'Chattogram Division', 'CTG', 22.65, 92.18, 'LAKE HILLS', 'lake fingers, steep forested hills and boats', 'Kaptai Lake islands', 'Karnaphuli', 'hill', '#7eae71'),

  d('bogura', 'Bogura', 'Rajshahi Division', 'RAJ', 24.85, 89.37, 'NORTH PLAIN', 'rice fields, town grids and red soil', 'Mahasthangarh zone', 'Karatoa', 'farmland', '#c59d61'),
  d('chapainawabganj', 'Chapainawabganj', 'Rajshahi Division', 'RAJ', 24.60, 88.28, 'MANGO COUNTRY', 'orchard rows, dry fields and Padma chars', 'Mango orchard canopy', 'Mahananda', 'orchard', '#c99d56'),
  d('joypurhat', 'Joypurhat', 'Rajshahi Division', 'RAJ', 25.10, 89.02, 'NORTH FIELDS', 'open crop fields and low village roofs', 'Akkelpur rail trace', 'Little Jamuna', 'farmland', '#b7a062'),
  d('naogaon', 'Naogaon', 'Rajshahi Division', 'RAJ', 24.81, 88.94, 'PADDY ATLAS', 'broad agricultural geometry and ponds', 'Atrai river plain', 'Atrai', 'farmland', '#b79f61'),
  d('natore', 'Natore', 'Rajshahi Division', 'RAJ', 24.42, 89.00, 'LAKE PALACE', 'quiet wet fields and old palace grounds', 'Uttara Ganabhaban', 'Baral', 'wetland', '#9eb271'),
  d('pabna', 'Pabna', 'Rajshahi Division', 'RAJ', 24.01, 89.24, 'RIVER FRONTIER', 'open fields, chars and river crossings', 'Ishwardi rail corridor', 'Ganges', 'river', '#6eb69b'),
  d('rajshahi', 'Rajshahi', 'Rajshahi Division', 'RAJ', 24.37, 88.60, 'PADMA SUNSET', 'dry riverbank, mango rows and urban edge', 'Padma river promenade', 'Padma', 'orchard', '#d6a05a'),
  d('sirajganj', 'Sirajganj', 'Rajshahi Division', 'RAJ', 24.45, 89.70, 'JAMUNA BEND', 'wide braided river and shifting chars', 'Jamuna Bridge approach', 'Jamuna', 'river', '#6fb9a1'),

  d('bagerhat', 'Bagerhat', 'Khulna Division', 'KHL', 22.66, 89.79, 'MANGROVE GATE', 'tidal creeks, palms and low green islands', 'Sixty Dome Mosque zone', 'Panguchi', 'mangrove', '#78aa6c'),
  d('chuadanga', 'Chuadanga', 'Khulna Division', 'KHL', 23.64, 88.84, 'WESTERN RAIL', 'open farmland and low dry horizon', 'Mathabhanga river line', 'Mathabhanga', 'farmland', '#bf9c5b'),
  d('jashore', 'Jashore', 'Khulna Division', 'KHL', 23.17, 89.21, 'GARDEN DISTRICT', 'orchard belts, ponds and town streets', 'Bhairab river edge', 'Bhairab', 'orchard', '#91b76d'),
  d('jhenaidah', 'Jhenaidah', 'Khulna Division', 'KHL', 23.55, 89.17, 'GREEN PLAIN', 'rice fields, groves and gentle waterways', 'Nabaganga bends', 'Nabaganga', 'farmland', '#82b870'),
  d('khulna', 'Khulna', 'Khulna Division', 'KHL', 22.85, 89.54, 'RIVER INDUSTRIAL', 'riverfront industry and mangrove approach', 'Rupsha Bridge view', 'Rupsha', 'urban', '#c79f54'),
  d('kushtia', 'Kushtia', 'Khulna Division', 'KHL', 23.90, 89.12, 'PADMA NORTH BANK', 'fields, groves and slow river loops', 'Lalon Shah Bridge', 'Gorai', 'river', '#6fb393'),
  d('magura', 'Magura', 'Khulna Division', 'KHL', 23.49, 89.42, 'QUIET GREEN', 'flat agriculture with homestead clusters', 'Nabaganga crossings', 'Nabaganga', 'farmland', '#83b775'),
  d('meherpur', 'Meherpur', 'Khulna Division', 'KHL', 23.76, 88.63, 'BORDER LIGHT', 'dry western fields and village shade', 'Mujibnagar memorial zone', 'Bhairab', 'farmland', '#c2a15f'),
  d('narail', 'Narail', 'Khulna Division', 'KHL', 23.17, 89.50, 'RIVER ORCHARDS', 'water lanes, fields and palm clusters', 'Chitra river route', 'Chitra', 'river', '#72b99f'),
  d('satkhira', 'Satkhira', 'Khulna Division', 'KHL', 22.72, 89.07, 'TIDAL EDGE', 'saltwater channels, embankments and green flats', 'Sundarbans approach', 'Kobadak', 'mangrove', '#6fa978'),

  d('barguna', 'Barguna', 'Barishal Division', 'BAR', 22.16, 90.12, 'SOUTHERN TIDE', 'tidal rivers, chars and coastal villages', 'Payra river mouth', 'Payra', 'coastal', '#68bbb0'),
  d('barishal', 'Barishal', 'Barishal Division', 'BAR', 22.70, 90.37, 'VENICE OF THE SOUTH', 'canals, markets and river islands', 'Kirtankhola waterfront', 'Kirtankhola', 'river', '#6bc3bb'),
  d('bhola', 'Bhola', 'Barishal Division', 'BAR', 22.68, 90.65, 'ISLAND DELTA', 'wide channels, boats and char lands', 'Meghna estuary sweep', 'Meghna', 'wetland', '#67c4be'),
  d('jhalokathi', 'Jhalokathi', 'Barishal Division', 'BAR', 22.64, 90.20, 'CANAL CITY', 'narrow waterways, betel groves and boats', 'Sugandha river bends', 'Sugandha', 'river', '#70c4aa'),
  d('patuakhali', 'Patuakhali', 'Barishal Division', 'BAR', 22.36, 90.33, 'PAYRA HORIZON', 'coastal plain, canals and wind-blown palms', 'Kuakata beach line', 'Andharmanik', 'coastal', '#d3a66a'),
  d('pirojpur', 'Pirojpur', 'Barishal Division', 'BAR', 22.58, 89.98, 'GREEN WATERWAYS', 'canals, orchards and soft delta light', 'Kacha river crossing', 'Kacha', 'river', '#75c5aa'),

  d('habiganj', 'Habiganj', 'Sylhet Division', 'SYL', 24.38, 91.42, 'TEA THRESHOLD', 'tea gardens, low hills and wetland light', 'Sreemangal tea horizon', 'Khowai', 'tea', '#76aa68'),
  d('moulvibazar', 'Moulvibazar', 'Sylhet Division', 'SYL', 24.48, 91.78, 'TEA COUNTRY', 'tea terraces, forest and rolling hill lines', 'Lawachara canopy', 'Manu', 'tea', '#75a86a'),
  d('sunamganj', 'Sunamganj', 'Sylhet Division', 'SYL', 25.07, 91.40, 'HAOR SKY', 'open wetland, monsoon water and distant hills', 'Tanguar haor sweep', 'Surma', 'wetland', '#72b7c0'),
  d('sylhet', 'Sylhet', 'Sylhet Division', 'SYL', 24.89, 91.87, 'TEA & STONE', 'tea slopes, wetland, stone rivers and hills', 'Jaflong stone river', 'Surma', 'tea', '#77ae70'),

  d('dinajpur', 'Dinajpur', 'Rangpur Division', 'RNG', 25.63, 88.64, 'NORTH HARVEST', 'wide fields, ponds and historic brickwork', 'Kantajew Temple zone', 'Punarbhaba', 'farmland', '#c19d60'),
  d('gaibandha', 'Gaibandha', 'Rangpur Division', 'RNG', 25.33, 89.54, 'BRAHMAPUTRA PLAIN', 'riverine sandbars and rice geometry', 'Ghaghat river bends', 'Ghaghat', 'river', '#6fb69d'),
  d('kurigram', 'Kurigram', 'Rangpur Division', 'RNG', 25.81, 89.65, 'NORTH CHAR', 'braided rivers, chars and open horizon', 'Dharla river crossing', 'Dharla', 'river', '#70b9a1'),
  d('lalmonirhat', 'Lalmonirhat', 'Rangpur Division', 'RNG', 25.92, 89.45, 'TEESTA LINE', 'flat fields, rail lines and river glow', 'Teesta river view', 'Teesta', 'farmland', '#75b89a'),
  d('nilphamari', 'Nilphamari', 'Rangpur Division', 'RNG', 26.02, 88.86, 'NORTHWEST LIGHT', 'open paddy, village trees and clear sky', 'Tista barrage approach', 'Teesta', 'farmland', '#8bb777'),
  d('panchagarh', 'Panchagarh', 'Rangpur Division', 'RNG', 26.34, 88.56, 'HIMALAYAN WINDOW', 'tea fields, cool air and distant mountain haze', 'Tetulia horizon', 'Karatoa', 'tea', '#83ad74'),
  d('rangpur', 'Rangpur', 'Rangpur Division', 'RNG', 25.74, 89.28, 'NORTH STAR', 'fields, city ribbon and mango groves', 'Tajhat palace zone', 'Ghaghat', 'orchard', '#93b46d'),
  d('thakurgaon', 'Thakurgaon', 'Rangpur Division', 'RNG', 26.03, 88.47, 'RED EARTH NORTH', 'dry fields, mango orchards and rail trace', 'Tangon river plain', 'Tangon', 'orchard', '#bb9a5a'),

  d('jamalpur', 'Jamalpur', 'Mymensingh Division', 'MYM', 24.92, 89.95, 'JAMUNA NORTH', 'river plains, crop blocks and sandbars', 'Jhenai river route', 'Jhenai', 'river', '#70b79a'),
  d('mymensingh', 'Mymensingh', 'Mymensingh Division', 'MYM', 24.75, 90.40, 'BRAHMAPUTRA VIEW', 'riverfront city, fields and old trees', 'Brahmaputra promenade', 'Brahmaputra', 'river', '#6bb9a4'),
  d('netrokona', 'Netrokona', 'Mymensingh Division', 'MYM', 24.88, 90.73, 'HAOR FOOTHILLS', 'wetland, low hills and open water', 'Durgapur clay hills', 'Kangsha', 'wetland', '#79b4a0'),
  d('sherpur', 'Sherpur', 'Mymensingh Division', 'MYM', 25.02, 90.02, 'NORTH BORDER GREEN', 'foothill plains, sal groves and fields', 'Garo hill foothills', 'Maharashi', 'hill', '#78aa6c'),
]

export const DISTRICT_BY_ID = new Map(DISTRICTS.map(item => [item.id, item]))
export const DIVISIONS = [...new Set(DISTRICTS.map(item => item.division))]
