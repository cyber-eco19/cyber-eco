import * as THREE from 'three'
import type { Audio } from '../engine/audio'
import type { Input } from '../engine/input'
import type { Quality } from '../engine/save'
import type { Renderer } from '../engine/renderer'
import { CONFIG } from './config'
import { DISTRICTS, DISTRICT_BY_ID, type District } from './districts'
import { FlightCamera } from './flight-camera'
import { FlightWorld } from './flight-world'
import { tuning } from './tuning'

export type Mode = 'attract' | 'playing' | 'paused' | 'ended'
export type Hint = 'move' | 'look'
export type Compass = { angle: number; distance: number; rise: number }
export type FlightRun = {
  phase: 'playing' | 'won' | 'lost'
  district: District
  elapsed: number
  timeLeft: number
  altitude: number
  speed: number
  heading: number
  progress: number
  gatesHit: number
  totalGates: number
  unranked: boolean
  loseReason?: 'time'
}
export type GameHooks = {
  popup(text: string, at: { x: number; y: number }, kind: 'score' | 'hurt'): void
  hurt(): void
  hint(hint: Hint | null): void
  tutorialDone(): void
  end(run: FlightRun): void
}

const FLIGHT_LIMIT = 150
const MIN_ALTITUDE = 42
const MAX_ALTITUDE = 155
const TIMES = [
  { hour: 12, label: 'MIDDAY' },
  { hour: 17.6, label: 'GOLDEN HOUR' },
  { hour: 19.4, label: 'DUSK' },
  { hour: 23, label: 'NIGHT' },
  { hour: 5.8, label: 'DAWN' },
]

export class Game {
  mode: Mode = 'attract'
  run: FlightRun
  reducedMotion = false
  private readonly world: FlightWorld
  private readonly cameraRig = new FlightCamera()
  private readonly position = new THREE.Vector3()
  private selected: District = DISTRICTS[0]
  private heading = 0
  private pitch = -0.1
  private bank = 0
  private gateIndex = 1
  private gatesHit = 0
  private time = 0
  private tutorial: Hint | null = null
  private chaseView = false
  private engine: 'off' | 'starting' | 'on' = 'off'
  private spool = 0
  private groundSpeed = 0
  private airborne = false
  private minReached = false
  private passengers = 0
  private hourIndex = 0

  constructor(
    private readonly renderer: Renderer,
    private readonly input: Input,
    private readonly audio: Audio,
    private readonly hooks: GameHooks,
  ) {
    this.world = new FlightWorld()
    this.world.selectDistrict(this.selected)
    this.run = this.makeRun()
  }

  get camera(): THREE.PerspectiveCamera {
    return this.cameraRig.camera
  }

  get selectedDistrict(): District {
    return this.selected
  }

  selectDistrict(id: string): void {
    const district = DISTRICT_BY_ID.get(id)
    if (!district) return
    this.selected = district
    this.world.selectDistrict(district)
    this.run = this.makeRun()
    this.hooks.hint(null)
  }

  start(tutorial: boolean): void {
    tuning.activate('run')
    this.world.selectDistrict(this.selected)
    const route = this.world.routePoints
    const start = route[0] ?? new THREE.Vector3(0, 74, 90)
    const next = route[1] ?? new THREE.Vector3(30, 74, 50)
    const forward = next.clone().sub(start).setY(0).normalize()
    this.position.copy(start)
    this.position.y = 4.2
    this.heading = Math.atan2(forward.x, -forward.z)
    this.pitch = -0.1
    this.bank = 0
    this.gateIndex = 1
    this.gatesHit = 0
    this.time = 0
    this.engine = 'off'
    this.spool = 0
    this.groundSpeed = 0
    this.airborne = false
    this.minReached = false
    this.passengers = 0
    this.say('PRESS G TO START THE ENGINE')
    this.cameraRig.reset()
    this.world.setInFlight(true)
    this.world.setChaseView(this.chaseView)
    this.run = this.makeRun()
    this.mode = 'playing'
    this.input.endFrame()
    this.input.takeLook()
    this.tutorial = tutorial ? 'move' : null
    this.hooks.hint(this.tutorial)
  }

  pause(): void {
    if (this.mode === 'playing') this.mode = 'paused'
  }

  resume(): void {
    if (this.mode !== 'paused') return
    this.mode = 'playing'
    this.input.endFrame()
    this.input.takeLook()
  }

  toTitle(): void {
    this.mode = 'attract'
    this.world.setInFlight(false)
    this.hooks.hint(null)
  }

  setQuality(quality: Quality): void {
    this.renderer.applyQuality(quality)
  }

  step(dt: number): void {
    this.time += dt
    const playing = this.mode === 'playing'
    if (!playing) return
    if (this.input.consume('view')) {
      this.chaseView = !this.chaseView
      this.world.setChaseView(this.chaseView)
      this.hooks.popup(this.chaseView ? 'EXTERNAL CHASE VIEW' : 'COCKPIT VIEW', { x: window.innerWidth * 0.5, y: window.innerHeight * 0.28 }, 'score')
    }
    const turn = this.input.move.x
    const throttle = this.input.move.y
    const climb = this.input.altitude
    const boost = this.input.held('sprint')
    const cruise = CONFIG.player.sprintSpeed * (boost ? 1.55 : 1.18)
    const turnRate = 0.62
    if (this.input.consume('time')) {
      this.hourIndex = (this.hourIndex + 1) % TIMES.length
      this.world.setTimeOfDay(TIMES[this.hourIndex].hour)
      this.say(TIMES[this.hourIndex].label, 0.34)
    }
    if (this.input.consume('engine') && this.engine === 'off' && !this.airborne) {
      this.engine = 'starting'
      this.spool = 0
      this.say('ENGINE STARTING...')
    }
    if (this.engine === 'starting') {
      this.spool += dt
      if (this.spool >= 3) {
        this.engine = 'on'
        this.passengers = 12
        this.say('ENGINE ON - 12 PASSENGERS BOARDED - HOLD W TO ROLL')
      }
    }
    const grounded = !this.airborne
    this.heading += turn * turnRate * dt * (grounded ? THREE.MathUtils.clamp(Math.abs(this.groundSpeed) / 12, 0, 1) : 1)
    this.bank = grounded ? 0 : THREE.MathUtils.clamp(-turn * 0.78, -0.78, 0.78)
    const forward = new THREE.Vector3(Math.sin(this.heading), 0, -Math.cos(this.heading))
    let speed: number
    if (grounded) {
      if (this.engine === 'on') {
        if (throttle !== 0) this.groundSpeed += throttle * 14 * dt
        else this.groundSpeed -= Math.sign(this.groundSpeed) * Math.min(Math.abs(this.groundSpeed), 5 * dt)
        this.groundSpeed = THREE.MathUtils.clamp(this.groundSpeed, -6, 36)
        if (this.groundSpeed >= 24 && (climb > 0.2 || this.groundSpeed >= 34)) {
          this.airborne = true
          this.say('ROTATE - AIRBORNE')
        }
      } else this.groundSpeed = 0
      this.position.y = 4.2
      this.position.addScaledVector(forward, this.groundSpeed * dt)
      speed = Math.abs(this.groundSpeed)
    } else {
      const lift = this.position.y < MIN_ALTITUDE ? 14 : 0
      const floor = this.minReached ? MIN_ALTITUDE : 4.2
      this.position.y = THREE.MathUtils.clamp(this.position.y + (climb * 19 + lift) * dt, floor, MAX_ALTITUDE)
      if (this.position.y >= MIN_ALTITUDE) this.minReached = true
      const factor = THREE.MathUtils.clamp(1 + throttle * 0.9, -0.45, 2.0)
      speed = this.minReached ? cruise * factor : Math.max(this.groundSpeed, cruise * factor * 0.6)
      this.position.addScaledVector(forward, speed * dt)
    }
    this.pitch = THREE.MathUtils.damp(this.pitch, grounded ? 0 : -0.1 - climb * 0.16, 4, dt)
    this.run = { ...this.run, elapsed: this.run.elapsed + dt, timeLeft: Math.max(0, FLIGHT_LIMIT - this.run.elapsed), altitude: this.position.y, speed, heading: this.heading }
    const target = this.world.routePoints[this.gateIndex]
    if (target && this.position.distanceTo(target) < 13) {
      this.gatesHit += 1
      this.gateIndex = (this.gateIndex + 1) % Math.max(1, this.world.routePoints.length)
      this.run = { ...this.run, gatesHit: this.gatesHit, progress: this.gatesHit / this.run.totalGates }
      this.audio.play('pickup')
      this.hooks.popup(`WAYPOINT ${String(this.gatesHit).padStart(2, '0')} CLEARED`, { x: window.innerWidth * 0.5, y: window.innerHeight * 0.28 }, 'score')
      if (this.tutorial === 'move') {
        this.tutorial = 'look'
        this.hooks.hint('look')
      } else if (this.tutorial === 'look') {
        this.tutorial = null
        this.hooks.tutorialDone()
        this.hooks.hint(null)
      }
      if (this.gatesHit >= this.run.totalGates) this.finish(true)
    }
    if (this.run.timeLeft <= 0) this.finish(false)
    this.world.syncJet(this.position, this.heading)
  }

  render(_alpha: number, frameSeconds: number): void {
    if (this.mode === 'attract') {
      const t = this.time * 0.11
      const camera = this.cameraRig.camera
      camera.position.set(Math.sin(t) * 150, 70 + Math.sin(this.time * 0.17) * 10, Math.cos(t) * 150)
      camera.lookAt(0, 24, 0)
    } else {
      this.cameraRig.look(this.input.takeLook())
      if (this.chaseView) this.cameraRig.updateChase(this.position, this.heading, this.bank, frameSeconds, this.reducedMotion)
      else this.cameraRig.update(this.position, this.heading, this.pitch, this.bank, frameSeconds, this.reducedMotion)
    }
    this.world.update(frameSeconds, this.gateIndex)
    this.renderer.render(this.world.scene, this.cameraRig.camera)
    this.input.endFrame()
  }

  compass(): Compass | null {
    const target = this.world.routePoints[this.gateIndex]
    if (!target) return null
    const dx = target.x - this.position.x
    const dz = target.z - this.position.z
    const desired = Math.atan2(dx, -dz)
    let angle = desired - this.heading
    angle = Math.atan2(Math.sin(angle), Math.cos(angle))
    return { angle, distance: this.position.distanceTo(target), rise: target.y - this.position.y }
  }

  private say(text: string, y = 0.28): void {
    this.hooks.popup(text, { x: window.innerWidth * 0.5, y: window.innerHeight * y }, 'score')
  }

  private makeRun(): FlightRun {
    return { phase: 'playing', district: this.selected, elapsed: 0, timeLeft: FLIGHT_LIMIT, altitude: 4, speed: 8, heading: 0, progress: 0, gatesHit: 0, totalGates: 7, unranked: tuning.unranked }
  }

  private finish(won: boolean): void {
    if (this.mode !== 'playing') return
    if (won && this.passengers) this.say(`${this.passengers} PASSENGERS DELIVERED`, 0.34)
    this.run = { ...this.run, phase: won ? 'won' : 'lost', loseReason: won ? undefined : 'time' }
    this.mode = 'ended'
    this.world.setInFlight(true)
    this.audio.play(won ? 'win' : 'lose')
    this.hooks.hint(null)
    this.hooks.end(this.run)
  }
}
