import type { Audio } from '../engine/audio'
import type { I18n } from '../engine/i18n'
import type { Input } from '../engine/input'
import { type SaveData, type SaveStore } from '../engine/save'
import { DISTRICTS, type District } from '../game/districts'
import type { Compass, FlightRun, Hint } from '../game/game'

const FAVICON_URL = new URL('../../assets/share/favicon.png', import.meta.url).href

export type Screen = 'boot' | 'title' | 'hud' | 'pause' | 'settings' | 'results'
export type UiActions = {
  play(): void
  resume(): void
  restart(): void
  quit(): void
  selectDistrict(id: string): void
  settings(patch: Partial<SaveData>): void
}

const escapeHtml = (value: string): string => value.replace(/[<>&"']/g, char => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&#39;' }[char] ?? char))
const clock = (seconds: number): string => `${Math.floor(seconds / 60)}:${String(Math.max(0, Math.ceil(seconds % 60))).padStart(2, '0')}`

export class Ui {
  screen: Screen = 'boot'
  private readonly root: HTMLElement
  private selected = DISTRICTS[0]
  private hintKey: Hint | null = null

  constructor(
    private readonly i18n: I18n,
    private readonly save: SaveStore,
    private readonly audio: Audio,
    private readonly input: Input,
    private readonly actions: UiActions,
  ) {
    this.root = document.getElementById('ui')!
    this.root.innerHTML = this.template()
    this.root.addEventListener('click', event => this.onClick(event))
    this.root.addEventListener('input', event => this.onInput(event))
    window.addEventListener('keydown', event => {
      if (event.code === 'Escape' && this.screen === 'settings') {
        event.preventDefault()
        this.show('pause')
        this.input.endFrame()
      }
    })
    this.renderDistricts()
    this.refreshSettings()
    this.translate()
  }

  show(screen: Screen): void {
    this.screen = screen
    for (const element of this.root.querySelectorAll<HTMLElement>('[data-screen]')) {
      const name = element.dataset.screen as Screen
      const active = name === screen || (name === 'hud' && ['pause', 'settings', 'results'].includes(screen))
      element.classList.toggle('is-active', active)
      element.setAttribute('aria-hidden', String(!active))
    }
    this.root.dataset.activeScreen = screen
    if (screen === 'title') this.renderSelected()
    if (screen === 'hud') this.renderHint()
  }

  setBootProgress(progress: number): void {
    const bar = this.root.querySelector<HTMLElement>('.boot-bar i')
    if (bar) bar.style.transform = `scaleX(${Math.max(0.04, Math.min(1, progress))})`
  }

  updateHud(run: FlightRun, compass: Compass | null): void {
    this.setText('[data-hud-district]', run.district.name.toUpperCase())
    this.setText('[data-hud-division]', `${run.district.divisionShort}  /  ${run.district.tag}`)
    this.setText('[data-hud-landmark]', run.district.landmark)
    this.setText('[data-hud-altitude]', `${Math.round(run.altitude).toString().padStart(3, '0')} MSL`)
    this.setText('[data-hud-speed]', `${Math.round(run.speed)} KT`)
    this.setText('[data-hud-heading]', `${String(Math.round((run.heading * 180) / Math.PI + 360) % 360).padStart(3, '0')}°`)
    this.setText('[data-hud-time]', clock(run.timeLeft))
    this.setText('[data-hud-waypoint]', `${String(run.gatesHit).padStart(2, '0')} / ${String(run.totalGates).padStart(2, '0')}`)
    const progress = this.root.querySelector<HTMLElement>('[data-hud-progress]')
    if (progress) progress.style.transform = `scaleX(${Math.max(0.02, run.progress)})`
    const compassEl = this.root.querySelector<HTMLElement>('.flight-compass')
    if (compassEl && compass) {
      compassEl.style.transform = `rotate(${-compass.angle}rad)`
      this.setText('[data-hud-distance]', `${Math.round(compass.distance)} M`)
    }
  }

  popup(text: string, at: { x: number; y: number }, kind: 'score' | 'hurt'): void {
    const el = document.createElement('div')
    el.className = `popup popup-${kind}`
    el.textContent = text
    el.style.left = `${at.x}px`
    el.style.top = `${at.y}px`
    this.root.append(el)
    window.setTimeout(() => el.remove(), 1800)
  }

  hurt(): void {
    const vignette = this.root.querySelector<HTMLElement>('.hurt-vignette')
    vignette?.classList.add('flash')
    window.setTimeout(() => vignette?.classList.remove('flash'), 420)
  }

  hint(hint: Hint | null): void {
    this.hintKey = hint
    this.renderHint()
  }

  frame(_frameSeconds: number): void {
    // The flight HUD is updated from simulation state; this hook keeps the starter loop contract.
  }

  showResults(run: FlightRun): void {
    this.setText('.results-kicker', run.phase === 'won' ? 'ROUTE COMPLETE' : 'ROUTE TIMEOUT')
    this.setText('.results-title', run.phase === 'won' ? `${run.district.name} FROM ABOVE` : 'THE ROUTE IS STILL OUT THERE')
    this.setText('.results-copy', run.phase === 'won' ? `You cleared the RJ Juice sightseeing loop over ${run.district.name}.` : 'The aircraft stayed within the Bangladesh route plan. Launch again to complete the loop.')
    this.setText('[data-result-waypoints]', `${run.gatesHit} / ${run.totalGates}`)
    this.setText('[data-result-time]', clock(run.elapsed))
    this.setText('[data-result-altitude]', `${Math.round(run.altitude)} MSL`)
    this.show('results')
  }

  refreshSettings(): void {
    const sensitivity = this.root.querySelector<HTMLInputElement>('[data-setting="sensitivity"]')
    const reduced = this.root.querySelector<HTMLInputElement>('[data-setting="reducedMotion"]')
    if (sensitivity) sensitivity.value = String(this.save.data.sensitivity)
    if (reduced) reduced.checked = this.save.data.reducedMotion
  }

  translate(): void {
    document.documentElement.lang = this.i18n.locale
  }

  private onClick(event: Event): void {
    const target = event.target as HTMLElement
    const button = target.closest<HTMLElement>('[data-action]')
    const action = button?.dataset.action
    if (action === 'play') { this.audio.unlock(); this.audio.startMusic(); this.actions.play() }
    else if (action === 'restart') { this.audio.unlock(); this.actions.restart() }
    else if (action === 'resume') this.actions.resume()
    else if (action === 'pause') window.dispatchEvent(new Event('game:pause'))
    else if (action === 'quit') { this.actions.quit(); this.show('title') }
    else if (action === 'settings') this.show('settings')
    else if (action === 'back') this.show('pause')
    const districtButton = target.closest<HTMLElement>('[data-district]')
    if (districtButton?.dataset.district) {
      this.actions.selectDistrict(districtButton.dataset.district)
      const district = DISTRICTS.find(item => item.id === districtButton.dataset.district)
      if (district) { this.selected = district; this.renderSelected() }
      this.audio.play('ui')
    }
  }

  private onInput(event: Event): void {
    const input = event.target as HTMLInputElement
    const key = input.dataset.setting
    if (key === 'sensitivity') this.actions.settings({ sensitivity: Number(input.value) })
    if (key === 'reducedMotion') this.actions.settings({ reducedMotion: input.checked })
  }

  private renderDistricts(): void {
    const map = this.root.querySelector('.map-nodes')
    const list = this.root.querySelector('.district-list')
    if (!map || !list) return
    map.innerHTML = DISTRICTS.map(district => `<button class="map-node" data-district="${district.id}" style="left:${this.mapX(district)}%;top:${this.mapY(district)}%" aria-label="Fly to ${escapeHtml(district.name)}" title="${escapeHtml(district.name)}"><span></span></button>`).join('')
    list.innerHTML = DISTRICTS.map(district => `<button class="district-row" data-district="${district.id}"><span class="district-code">${district.divisionShort}</span><strong>${escapeHtml(district.name)}</strong><small>${escapeHtml(district.landmark)}</small><i>↗</i></button>`).join('')
  }

  private renderSelected(): void {
    this.setText('[data-selected-name]', this.selected.name.toUpperCase())
    this.setText('[data-selected-division]', `${this.selected.division}  /  ${this.selected.tag}`)
    this.setText('[data-selected-terrain]', this.selected.terrain)
    this.setText('[data-selected-landmark]', this.selected.landmark)
    this.setText('[data-selected-river]', `${this.selected.river} corridor`)
    for (const node of this.root.querySelectorAll<HTMLElement>('[data-district]')) node.classList.toggle('is-selected', node.dataset.district === this.selected.id)
  }

  private renderHint(): void {
    const element = this.root.querySelector<HTMLElement>('.flight-hint')
    if (!element) return
    if (!this.hintKey) { element.classList.remove('is-visible'); return }
    const text = this.hintKey === 'move' ? 'W / S  throttle   ·   ↑ / ↓  altitude   ·   A / D  bank' : 'MOVE THE MOUSE  look around the cabin'
    element.textContent = text
    element.classList.add('is-visible')
  }

  private mapX(district: District): number {
    return Math.max(8, Math.min(92, 14 + ((district.lon - 88.2) / 4.05) * 73))
  }

  private mapY(district: District): number {
    return Math.max(10, Math.min(90, 88 - ((district.lat - 21.25) / 5.2) * 74))
  }

  private setText(selector: string, value: string): void {
    const element = this.root.querySelector<HTMLElement>(selector)
    if (element) element.textContent = value
  }

  private template(): string {
    return `<div class="screen screen-boot" data-screen="boot"><img class="boot-favicon" src="${FAVICON_URL}" alt="RJ Juice"><div class="boot-mark"><span>RJ</span><b>JUICE</b></div><div class="boot-bar"><i></i></div><div class="boot-label">LOADING BANGLADESH FLIGHT DECK</div></div>

      <section class="screen screen-title" data-screen="title">
        <div class="title-vignette"></div>
        <aside class="title-rail">
          <div class="logo"><span class="logo-wing">◈</span><div><h1 class="logo-text">RJ JUICE</h1><p>PRIVATE WINDOW / BANGLADESH</p></div></div>
          <p class="tagline">See the country from a different altitude. File a flight plan for any district, then take the long way around.</p>
          <div class="rail-note"><span class="status-dot"></span><div><b>OFFLINE SIGHTSEEING SYSTEM</b><small>64 DISTRICTS / ONE COUNTRY</small></div></div>
        </aside>
        <main class="flight-plan-panel">
          <div class="panel-kicker"><span>FLIGHT PLAN  /  RJ-064</span><span>23° 41′ N  ·  90° 21′ E</span></div>
          <div class="plan-layout">
            <div class="map-card">
              <div class="map-header"><div><span class="eyebrow">DESTINATION MAP</span><strong>BANGLADESH</strong></div><span class="map-count">64 DISTRICTS</span></div>
              <div class="map-stage"><svg viewBox="0 0 140 190" aria-hidden="true"><path d="M48 6 81 13 110 7 132 29 124 52 136 69 125 92 114 111 105 139 86 157 72 181 53 169 41 148 21 141 25 116 8 100 15 74 7 54 27 38 29 16Z"/><path class="map-river-line" d="M19 96C50 69 75 96 101 73S115 39 126 28M30 120C58 107 74 123 113 116"/></svg><div class="map-nodes"></div><div class="map-compass">N</div></div>
              <div class="map-legend"><span><i class="legend-dot selected"></i> RJ JUICE ROUTE</span><span><i class="legend-dot"></i> DISTRICT</span></div>
            </div>
            <div class="destination-card"><span class="eyebrow">SELECTED DESTINATION</span><h2 data-selected-name>DHAKA</h2><p class="destination-division" data-selected-division>Dhaka Division  /  CAPITAL PULSE</p><div class="destination-lines"><span>SCENIC PROFILE<strong data-selected-terrain>dense city fabric and river light</strong></span><span>FEATURED VIEW<strong data-selected-landmark>National Parliament skyline</strong></span><span>WATERWAY<strong data-selected-river>Buriganga corridor</strong></span></div><button class="btn btn-primary launch-btn" data-action="play"><span>FLY TO DESTINATION</span><b>↗</b></button><div class="launch-meta"><span>WASD / MOUSE</span><span>PRIVATE JET  ·  RJ JUICE</span></div></div>
          </div>
          <div class="district-browser"><div class="browser-heading"><span class="eyebrow">ALL DESTINATIONS</span><span>SELECT ANY DISTRICT TO UPDATE THE ROUTE</span></div><div class="district-list"></div></div>
        </main>
          <div class="title-footer"><span>SCENIC SIMULATION  /  OPEN GEOGRAPHY: OSM · SRTM</span><span>BUILD 01.64</span></div>
      </section>

      <section class="screen screen-hud" data-screen="hud">
        <div class="flight-topbar"><div class="flight-brand"><span class="mini-wing">◈</span><div><b>RJ JUICE</b><small>PRIVATE WINDOW</small></div></div><div class="flight-route"><span>ON ROUTE</span><strong data-hud-district>DHAKA</strong><small data-hud-division>DHA  /  CAPITAL PULSE</small></div><div class="flight-topstats"><span>ALT <b data-hud-altitude>070 MSL</b></span><span>HDG <b data-hud-heading>000°</b></span><span>TIME <b data-hud-time>2:30</b></span><button class="icon-btn" data-action="pause" aria-label="Pause">Ⅱ</button></div></div>
        <div class="flight-crosshair"><span></span><i></i></div><div class="flight-compass-ring"><span class="flight-compass">◆</span><b>NAVIGATE</b><small data-hud-distance>000 M</small></div>
        <div class="flight-side-panel"><span class="eyebrow">SIGNATURE VIEW</span><strong data-hud-landmark>National Parliament skyline</strong><div class="side-rule"></div><span class="eyebrow">WAYPOINTS CLEARED</span><strong data-hud-waypoint>00 / 07</strong><div class="route-progress"><i data-hud-progress></i></div></div>
        <div class="cockpit-frame"><div class="cockpit-left"></div><div class="cockpit-right"></div><div class="cockpit-glass"></div><div class="instrument-shelf"><div class="instrument"><span>SPD</span><b data-hud-speed>013 KT</b></div><div class="instrument"><span>FLIGHT DECK</span><b>SIGHTSEEING</b></div><div class="instrument"><span>ROUTE</span><b>RJ-064</b></div></div></div><div class="touch"><div class="touch-stick"><i></i></div></div>
        <div class="flight-bottom"><span><kbd>W</kbd><kbd>S</kbd> THROTTLE / REVERSE</span><span><kbd>↑</kbd><kbd>↓</kbd> CLIMB / DIVE</span><span><kbd>A</kbd><kbd>D</kbd> BANK</span><span><kbd>SHIFT</kbd> BOOST</span><span><kbd>V</kbd> EXTERNAL VIEW</span><span><kbd>ESC</kbd> PAUSE</span></div><div class="flight-hint"></div><div class="hurt-vignette"></div><div class="popups"></div>
      </section>

      <section class="screen screen-modal" data-screen="pause"><div class="modal-card pause-card"><span class="eyebrow">RJ JUICE  /  FLIGHT DECK</span><h2>FLIGHT PAUSED</h2><p>Take a breath. The view will be right where you left it.</p><div class="modal-actions"><button class="btn btn-primary" data-action="resume"><span>RESUME FLIGHT</span></button><button class="btn btn-secondary" data-action="settings"><span>SETTINGS</span></button><button class="btn btn-secondary" data-action="quit"><span>RETURN TO MAP</span></button></div></div></section>

      <section class="screen screen-modal" data-screen="settings"><div class="modal-card settings-card"><span class="eyebrow">FLIGHT DECK PREFERENCES</span><h2>SETTINGS</h2><label class="setting-row"><span>LOOK SENSITIVITY</span><input type="range" min="0.5" max="1.5" step="0.05" data-setting="sensitivity"></label><label class="setting-row"><span>REDUCED MOTION</span><input type="checkbox" data-setting="reducedMotion"></label><button class="btn btn-primary" data-action="back"><span>BACK TO FLIGHT</span></button></div></section>

      <section class="screen screen-modal" data-screen="results"><div class="modal-card results-card"><span class="eyebrow results-kicker">ROUTE COMPLETE</span><h2 class="results-title">DHAKA FROM ABOVE</h2><p class="results-copy">You cleared the RJ Juice sightseeing loop.</p><div class="result-stats"><span><b data-result-waypoints>07 / 07</b><small>WAYPOINTS</small></span><span><b data-result-time>0:00</b><small>AIR TIME</small></span><span><b data-result-altitude>070 MSL</b><small>LAST ALTITUDE</small></span></div><div class="modal-actions"><button class="btn btn-primary" data-action="restart"><span>FLY AGAIN</span></button><button class="btn btn-secondary" data-action="quit"><span>CHOOSE ANOTHER DISTRICT</span></button></div></div></section>`
  }
}
