import { spawn } from 'node:child_process'
import { mkdirSync } from 'node:fs'
import { chromium } from 'playwright'
const port = 4300 + Math.floor(Math.random() * 500)
const url = `http://127.0.0.1:${port}/`
const out = process.env.SHOTS_DIR ?? 'shots'
mkdirSync(out, { recursive: true })
const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', 'preview', '--port', String(port), '--strictPort', '--host', '127.0.0.1'], { stdio: 'ignore' })
let browser
const guard = setTimeout(() => fail('timed out'), 120_000)
function cleanup() { clearTimeout(guard); try { server.kill('SIGTERM') } catch {} }
async function fail(msg) { console.error(`smoke: FAIL — ${msg}`); await browser?.close().catch(() => {}); cleanup(); process.exit(1) }
async function waitForServer() { for (let i = 0; i < 60; i += 1) { try { if ((await fetch(url)).ok) return } catch {} await new Promise(r => setTimeout(r, 250)) } throw new Error('preview server did not start') }
async function openGame(context, errors) {
  const page = await context.newPage()
  page.on('console', m => m.type() === 'error' && errors.push(m.text()))
  page.on('pageerror', e => errors.push(String(e)))
  page.on('response', r => r.status() >= 400 && errors.push(`HTTP ${r.status()} ${r.url()}`))
  await page.goto(url)
  await page.waitForSelector('[data-screen="title"].is-active', { timeout: 30_000 })
  await page.evaluate(async () => {
    await document.fonts.ready
    const expected = document.documentElement.lang === 'zh-CN' ? 'ManusCC0Sans' : 'ManusCC0'
    for (const selector of ['.logo-text', '.tagline']) {
      const family = getComputedStyle(document.querySelector(selector)).fontFamily
      if (!family.startsWith(`"${expected}"`) && !family.startsWith(expected + ',')) throw new Error(`Unexpected game font: ${family}`)
    }
  })
  await page.waitForTimeout(700)
  return page
}
const state = page => page.evaluate(() => {
  const { game } = window.__game
  const pos = game['position']
  return { mode: game.mode, run: game.run, pos: { x: pos.x, y: pos.y, z: pos.z } }
})
try {
  await waitForServer()
  browser = await chromium.launch({ args: ['--ignore-gpu-blocklist'] }).catch(() => chromium.launch({ args: ['--ignore-gpu-blocklist'], executablePath: '/usr/bin/chromium' }))
  const errors = []
  const en = await browser.newContext({ viewport: { width: 1440, height: 900 }, locale: 'en-US' })
  const page = await openGame(en, errors)
  await page.screenshot({ path: `${out}/01-title-en.png` })
  await page.click('[data-district="sylhet"]')
  await page.waitForFunction(() => document.querySelector('[data-selected-name]')?.textContent === 'SYLHET')
  await page.screenshot({ path: `${out}/02-sylhet-plan.png` })
  await page.click('[data-action="play"]')
  await page.waitForSelector('[data-screen="hud"].is-active')
  const before = await state(page)
  await page.keyboard.down('KeyW')
  await page.keyboard.down('KeyD')
  await page.waitForTimeout(1000)
  await page.keyboard.up('KeyW'); await page.keyboard.up('KeyD')
  await page.waitForTimeout(500)
  await page.screenshot({ path: `${out}/03-flight.png` })
  const after = await state(page)
  const moved = Math.hypot(after.pos.x - before.pos.x, after.pos.z - before.pos.z)
  if (after.mode !== 'playing') throw new Error(`expected playing, got ${after.mode}`)
  if (!(after.run.elapsed > before.run.elapsed)) throw new Error('flight clock did not run')
  if (moved < 2) throw new Error(`jet barely moved (${moved.toFixed(2)} m)`)
  await page.keyboard.press('Escape')
  await page.waitForSelector('[data-screen="pause"].is-active')
  await page.screenshot({ path: `${out}/04-pause.png` })
  await page.click('[data-screen="pause"] [data-action="settings"]')
  await page.waitForSelector('[data-screen="settings"].is-active')
  await page.screenshot({ path: `${out}/05-settings.png` })
  await page.click('[data-screen="settings"] [data-action="back"]', { force: true })
  await page.waitForSelector('[data-screen="pause"].is-active')
  if ((await state(page)).mode !== 'paused') throw new Error('leaving Settings with Escape resumed the flight')
  await page.click('[data-action="resume"]')
  await page.waitForSelector('[data-screen="hud"].is-active')
  await page.evaluate(() => {
    const { game } = window.__game
    game.resume()
    game['takeoffElapsed'] = 7
    const world = game['world']
    const route = world.routePoints
    for (let i = 1; i <= route.length; i += 1) {
      game['position'].copy(route[i % route.length])
      game.step(1 / 60)
    }
  })
  await page.waitForSelector('[data-screen="results"].is-active', { timeout: 10_000 })
  await page.screenshot({ path: `${out}/06-results.png` })
  if ((await state(page)).run.phase !== 'won') throw new Error('expected a won route')
  await en.close()
  const phone = await browser.newContext({ viewport: { width: 844, height: 390 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: 'en-US' })
  const phonePage = await openGame(phone, errors)
  await phonePage.click('[data-action="play"]')
  await phonePage.waitForSelector('[data-screen="hud"].is-active')
  await phonePage.waitForTimeout(900)
  await phonePage.screenshot({ path: `${out}/07-phone-hud.png` })
  await phone.close()
  if (errors.length) throw new Error(`console errors:\n  ${errors.join('\n  ')}`)
  await browser.close(); cleanup(); console.log(`smoke: OK — screenshots in ${out}/`)
} catch (err) { await fail(err?.message ?? String(err)) }
