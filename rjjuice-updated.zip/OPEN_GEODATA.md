# Open geographic data used by RJ Juice

RJ Juice now uses an open real-world geography layer instead of relying only on procedural scenery.

## Administrative boundaries

The selected-district boundary geometry comes from the Bangladesh administrative boundary dataset published by OCHA/HDX. It contains the country's 64 district (ADM2) boundaries. The game stores a simplified browser-ready derivative at `src/game/bangladesh-boundaries.json`.

Source: https://data.humdata.org/dataset/cod-ab-bgd

## Roads

The major-road overlay is derived from the Bangladesh OpenStreetMap extract maintained by the Bangladesh GeoJSON project. The game stores a simplified subset of trunk, primary and secondary routes at `src/game/bd-major-routes.json`.

Source repository: https://github.com/ifahimreza/bangladesh-geojson

OpenStreetMap data is used under ODbL 1.0. Attribution: **© OpenStreetMap contributors — ODbL 1.0**.

## Elevation layer

The current realism pass includes compact SRTM elevation grids for the flagship destination tiles in `public/data/bangladesh-elevation.json`. The source is the open AWS Terrain Tiles S3 dataset, based on global terrain elevation data, with SRTM 1 arc-second coverage described by USGS as approximately 30 m elevation posts. The game uses downsampled height grids to shape the Three.js terrain without requiring an API key.

AWS Terrain Tiles source: https://registry.opendata.aws/terrain-tiles/

USGS SRTM source: https://www.usgs.gov/centers/eros/science/usgs-eros-archive-digital-elevation-shuttle-radar-topography-mission-srtm-1

The next realism pass can add more SRTM tiles for the remaining districts and legally usable Sentinel-2 surface imagery. Copernicus describes GLO-30 as worldwide 30 m digital surface elevation and Sentinel-2 data as available free of charge to general, scientific and commercial users, subject to the applicable access and use conditions.

Copernicus DEM source: https://dataspace.copernicus.eu/explore-data/data-collections/copernicus-contributing-missions/collections-description/COP-DEM

Sentinel-2 source: https://dataspace.copernicus.eu/data-collections/copernicus-sentinel-missions/sentinel-2

The current upgrade improves geographic accuracy with real district borders and highway corridors. It does not claim pixel-level photogrammetry or copy Google imagery.
