# RJ Juice — Bangladesh from the Sky

## Product scope

A browser-based Three.js sightseeing flight game in which the player selects any of Bangladesh's 64 districts and flies a private jet branded **RJ Juice** from a cockpit-like first-person view. The initial complete slice must be playable, polished and clearly structured for district-by-district expansion. It uses the approved Three.js game starter, stays offline/static with no login, leaderboard or payments, and keeps all destinations inside Bangladesh.

The first implementation includes: a Bangladesh-only destination selector with all 64 districts; an attract/title presentation; a first-person cockpit flight view; a looped sightseeing route around the selected district; responsive flight controls; terrain, rivers, roads, vegetation, clouds, route gates and recognizable landmark treatment; named district metadata for future detailed scene packs; and a professional HUD showing altitude, speed, heading, district and sightseeing progress.

The project is served as a static Vite build. The game scene is client-rendered in Three.js with procedural scenery and the selected catalog aircraft model. The retrieved aircraft asset is a CC0 light business jet used as the RJ Juice base and styled in code with cyan/gold brand accents. No backend or database is required for the current offline game.

## Project structure

- `src/game/districts.ts`: authoritative 64-district table, divisions, coordinates, terrain families, landmark labels and scenic palettes.
- `src/game/world.ts`: procedural Bangladesh-inspired flight world, rivers, roads, fields, hills, clouds, landmark props, route gates and title panorama.
- `src/game/game.ts`: flight state machine, destination selection, flight physics, cockpit camera, route progression and GLB aircraft loading.
- `src/game/config.ts`: flight tuning defaults and camera values.
- `src/game/tuning.ts`: existing Tweak-compatible parameter manager adapted to speed, turn rate, altitude and camera controls.
- `src/ui/ui.ts`: HTML/CSS destination selector, Bangladesh map panel, HUD, pause and results screens.
- `src/styles/main.css`: aviation-atlas visual system and responsive layout.
- `src/i18n/*.json`: player-facing text catalogs.
- `assets/models/`: managed catalog model source; runtime consumes the model through a Vite URL import.
- `game-sharing.json`, `assets/share/`: first-complete-game sharing metadata, favicon and OG art.

## Design direction

### Style options

- Aviation atlas / dark navy flight deck with luminous route lines and chart labels — 0.07
- Tropical documentary / river teal, monsoon green and sunset amber with cinematic travel captions — 0.06
- Retro airline poster / cream, scarlet and brass with bold destination stamps — 0.04

Chosen style: **Aviation atlas**.

### Design movement

Modern aviation instrument panel meets premium travel documentary: restrained dark surfaces, precise chart marks, soft glass, and luminous navigation accents over a cinematic Bangladesh-from-above world.

### Core principles

1. Navigation first: every screen should make destination, heading and next action obvious.
2. Grounded wonder: scenic content is calm and beautiful, while labels and flight data make it feel like a real itinerary.
3. Professional restraint: use a small palette, deliberate spacing and clear hierarchy instead of arcade clutter.
4. Expandable realism: the 64-district table is a content spine; every district has a named terrain and landmark hook ready for higher-fidelity art/data packs.

### Color philosophy

Midnight navy and ink-black surfaces evoke a cockpit at dusk and keep the 3D scenery dominant. Radar cyan marks active navigation and map focus. RJ Juice gold marks destination, brand and success states. River teal, monsoon green and warm amber are reserved for terrain families and landmark accents, so the country reads as varied without losing the shared atlas system.

### Layout paradigm

Use a split command-deck composition: a left vertical itinerary rail for brand and destination context, a large map/chart field for choosing a district, and a bottom flight strip for controls and status. In flight, collapse the rail into a slim top telemetry bar and keep the cockpit HUD on the lower third, leaving the horizon open.

### Signature elements

- **Flightline motif:** thin cyan route lines, waypoint dots and dashed map arcs repeated across map, HUD and results.
- **RJ Juice badge:** a small rounded rectangular wing mark with a cyan nose line and gold tail stripe, used on the logo, jet livery and selected destination state.
- **Chart annotations:** uppercase micro-labels, coordinates, division tags and tiny compass ticks that frame rather than obscure scenic views.

### Interaction philosophy

Choosing a district should feel like filing a flight plan: click a district node or list row, review its terrain and signature, then launch. In flight, WASD/arrow controls adjust bank and climb, Shift boosts, mouse looks around, and Esc pauses. Controls should be discoverable in the lower rail and usable on touch through the existing touch layer.

### Animation

Menus use restrained 160–260ms slide/fade transitions. Map nodes pulse only for the selected or recommended destination. The 3D jet cruises with a small banking response and subtle cockpit motion; clouds drift slowly; route gates shimmer only when near. Avoid constant screen shake and keep reduced-motion support by disabling camera bob, route shimmer and nonessential pulsing.

### Typography system

Use the starter's bundled ManusCC0 display and body fonts. Large titles are condensed-feeling, uppercase, slightly tracked and used sparingly. Telemetry uses medium weight with compact numeric figures. Supporting copy is regular weight with comfortable line height. The primary family remains the bundled face because this is a Three.js game starter.

### Brand essence

**A private-window view of Bangladesh, district by district.** For curious travelers who want to see the country from the sky before they visit. Different, calm, precise.

### Brand voice

Headlines are confident and invitational: “FILE A FLIGHT PLAN.” CTAs are direct: “FLY TO SYLHET.” Microcopy is factual but warm: “Tea country, wetland light, and a clean loop over the Surma.”

### Wordmark & logo

The RJ Juice wordmark is a forward-leaning uppercase lockup paired with a compact wing badge: a cyan flightline cuts through the R, while a gold tail stripe underlines JUICE. Avoid a generic text-only logo by including the badge and route-line detail in the UI.

### Signature brand color

**Route Cyan `#79e6e8`** — the ownable RJ Juice navigation color, used for selected routes, cockpit instruments and map focus.

## Implementation decisions

- Keep the existing engine loop, renderer, input, save and tuning bridge; replace only the game-facing modules and UI presentation.
- Use a lightweight custom flight simulation in the fixed-step `Game.step()` path rather than platform physics: forward cruise speed, bank/turn, climb/dive, altitude floor, route gates and scenic progress.
- Use a reusable scene recipe by terrain family, then personalize each district from the central data table. Chattogram includes a port/ship-crane landmark cluster; Sylhet includes tea terraces, wetland water and hill silhouettes.
- Use the catalog CC0 light business jet GLB as the base aircraft, load it with the existing GLTF loader path, and apply RJ Juice brand materials/lighting in the scene. Keep a procedural fallback so the game remains recoverable if the model is unavailable.
- Keep game data and player-facing copy local/static. The first build is not a survey-grade digital twin; it is an expandable sightseeing prototype whose real-world fidelity can be increased through sourced GIS, satellite/photogrammetry and landmark packs in later iterations.
- Prepare game sharing metadata and a game-specific favicon before the first complete checkpoint. Generate an OG cover only after the playable scene is complete, using the actual game direction.

## Delivery and validation

Use `pnpm build`, the existing smoke harness adapted for district selection, flight movement, pause/resume and responsive title/HUD capture, and a real Webdev Preview. Before checkpointing, run asset sync/validation, sharing preparation, build, smoke and the canonical Cloud Git checkpoint flow. Do not publish unless explicitly requested.
